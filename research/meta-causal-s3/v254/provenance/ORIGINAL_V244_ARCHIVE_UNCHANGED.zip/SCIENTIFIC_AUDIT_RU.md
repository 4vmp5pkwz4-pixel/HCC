# Аудит META–CAUSAL / S³ v244, 16 октября 2026

Из исходной v232 сохранены все 232 результата и добавлены 12 проверенных в заявленной области математических утверждений 233–244. **Новых экспериментально подтверждённых законов природы не заявлено.** Три особенно важных исправления: добавление канала не уменьшает KL при фиксированных вероятностных моделях; простая замена базиса nuisance не меняет информацию Фишера; космическую дисперсию нельзя без дополнительных предположений подменять белым приборным шумом.

Проверено **6179** численных и конечных тестов, отказов: **0**. Два независимых способа подсчёта кратностей скалярных гармоник линзовых пространств совпали в 574 случаях. Для L(5,1) и L(5,2) кратности n=2 составляют 3 и 1. Это известное следствие спектральной теории, не доказательство космологической топологии.

Ссылка на исходник COMPACT/CMB-for-S3 подтверждена, но **его расчёт CMB-матриц не запускался** из-за отсутствия CAMB; сверка физических ковариаций не выполнена. Все 150 предложенных пунктов 281–430 получили предварительную метку в TRIAGE_281_430.json, однако это не эквивалентно полной проверке каждого пункта.

# Scientific audit: META--CAUSAL / S³ v244 (16 October 2026)

**Status:** research manuscript, not submitted/accepted by Physical Review D; no discovery of cosmic topology or new force. This is a targeted mathematical audit of user-proposed 281–430, not evidence that all 150 have been proved or disproved.

## Canonical continuity

- 232 original numbered results preserved; 12 results 233–244 inserted before limitations and bibliography.
- Source base: `META_CAUSAL_S3_232_PRD.tex`, unchanged in `provenance/`.
- 8 original scientific figures retained; one new scalar lens-spectrum benchmark figure.
- Historical novelty of added identities not established; most are known mathematical statistics, elementary representation-theoretic results or counterexamples.

## Main mathematical findings

1. For fixed joint laws, `D(P_XY || Q_XY) = D(P_X || Q_X) + E_{P_X} D(P_Y|X || Q_Y|X)`; the second term cannot be negative even for strongly correlated E/B channels.
2. Exact Gaussian conditional-polarization gain is a sum of a covariance KL term and a nonnegative conditional-mean correction. It provides a useful basis for real-data computations once actual covariances are available.
3. With consistent nuisance scores, efficient/profiled Fisher cannot decline merely because Y was additionally observed. Bayesian evidence for one realization, different priors or changed model families are distinct comparisons.
4. The profile-Fisher asymptotic is sigma^-4 under fixed covariance tangents and strictly positive nuisance-orthogonal residual. Coordinate changes preserving nuisance span do not alter the coefficient.
5. A two-dimensional relative-rotation counterexample has exact derivative -0.75. In contrast, simultaneous common rotation of both laws preserves KL.
6. Weak-signal KL begins at quadratic order and retains cross-shell terms at that same order.
7. For any distinct aligned cyclic orders p<q, new differing harmonic directions appear indefinitely; cumulative rank does not saturate.
8. Independent scalar harmonic counting from equivariant homogeneous polynomials and SU(2)xSU(2) weight character selection agreed, without using CMB transfer functions.
9. Equal-volume lens spaces L(5,1) and L(5,2) already differ at scalar n=2: multiplicity 3 versus 1.
10. An angular Clebsch-Gordan projection cannot be surjective if its invariant source dimension is below 2ell+1.

## Scope of numerical verification

`verify_233_244.py` seed 20261016; **6179 checks**, 0 failures. Exact category counts: {'Gaussian conditional KL identity': 480, 'Additional channel cannot reduce KL': 480, 'Profile Fisher monotonic under joint extension': 480, 'Nuisance basis invariance': 210, 'High noise coefficient': 210, 'No finite noise extinction away nuisance span': 210, 'Weak signal quadratic KL': 480, '2d nonstationary KL example': 1, 'Independent polynomial-vs-character scalar multiplicities': 574, 'Lens multiplicity admissible': 574, 'Infinite rank-jump witness for distinct orders': 2445, 'Angular projection cannot surject if source dimension less than target': 35}.

This does not constitute formal Lean proof or physical CMB data fit. The script independently recomputes 574 scalar lens multiplicities by two distinct finite enumerations. The external CMB-for-S3 repository requires CAMB; CAMB was unavailable in the environment. **No full COMPACT covariance agreement is claimed.**

## Corrections to proposals 281--430

- False full-data KL decrease: 285, 295, 305, 322 (common pair of joint laws).
- Nuisance basis-change dependence: 290 (false for an invertible basis change; true for different nuisance subspace).
- Universal orientation stationarity / genericity: 303, 314, 372, 402 (false or unproved without extra hypotheses).
- Unqualified off-diagonal dominance: 367, 377, 397, 407, 427 (empirical, not a theorem).
- Claim that curvature affects covariance only through nearest clone distance: 348, 391, 421 (false in general).
- Treating cosmic variance as additive white instrument noise: 319, 326, 345, 375, 405 (not exact).
- Claims that all COMPACT outputs omit noise/lensing: 382, 412 (not documented as universal).
- Conditional truthful: 281, 282, 286, 288, 292, 297, 307, 308 under fixed-tangent Gaussian assumptions.

Every numbered proposal has an explicit provisional category in `TRIAGE_281_430.json`. "Not independently adjudicated" means no individual proof or counterexample was established, not that a proposal is true.

## External benchmark and next steps

COMPACT *Cosmic topology, Part IId* arXiv:2610.12418 supplies scalar covariances for arbitrary lens spaces and observer positions. Public numerical implementation: https://github.com/CompactCollaboration/CMB-for-S3. Its public `compute_matrices.py` saves covariance and KL results; its `s3topologies.py` obtains scalar CAMB transfers. Do not treat this as a verified tensor B-mode reference.

Reproduce scalar lens matrices with matched OmegaK, cosmological parameters, lmax, mode truncation, observer frames, normalization and basis. Only after an independently verified scalar baseline should one extend tensor transfer and perform observation-level inference.
