# META–CAUSAL / S³ v244 reproducibility release

Canonical file: `META_CAUSAL_S3_244_PRD.tex`.

Reproduce finite check: `python verify_233_244.py`.
Render lens-spectrum comparison figure: `python make_figure.py`.
Compile with REVTeX 4.2 available in standard LaTeX: `pdflatex -interaction=nonstopmode -halt-on-error META_CAUSAL_S3_244_PRD.tex` (twice).

Original baseline v232 is retained under `provenance/` without changes.

The 12 new results are conditional mathematical claims, not confirmed novelty, observational cosmology, or Lean-verified theorems.
