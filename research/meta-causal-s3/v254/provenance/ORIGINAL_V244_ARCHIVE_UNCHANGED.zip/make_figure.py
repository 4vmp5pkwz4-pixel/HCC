from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import json
root=Path(__file__).parent
examples=json.loads((root/'VERIFICATION_233_244.json').read_text())['examples']['lens_scalar_multiplicities_n0_to8']
n=np.arange(9)
fig,ax=plt.subplots(figsize=(8.4,3.4))
w=.34
ax.bar(n-w/2,examples['L(5,1)'],width=w,label=r'$L(5,1)$')
ax.bar(n+w/2,examples['L(5,2)'],width=w,label=r'$L(5,2)$')
ax.set_xticks(n);ax.set_xlabel('Scalar Laplace harmonic degree n')
ax.set_ylabel('Invariant multiplicity')
ax.set_title('Equal fundamental group order and volume, distinct scalar spectrum')
ax.legend(frameon=False);ax.grid(axis='y',alpha=.22)
fig.tight_layout();fig.savefig(root/'figure_scalar_lens_crosscheck.pdf');fig.savefig(root/'figure_scalar_lens_crosscheck.png',dpi=160);plt.close(fig)
